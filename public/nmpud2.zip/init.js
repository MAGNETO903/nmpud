var p2_26 = Math.pow(2, 26);
var p2_14 = Math.pow(2, 14);


var right_shift_26_v2 = function(num) {
	return Math.trunc(num / p2_26)
}

var right_shift_14_v2 = function(num) {
	return Math.trunc(num / p2_14)
}

var left_shift_26 = function(num) {
	return num * p2_26;
}

var left_shift_14 = function(num) {
	return num * p2_14;
}

//console.log(shift_26(2105632645931929))

//console.log(45887173 >> 26)
//console.log(right_shift(45887173, 26))
u = [3, 0];
m = [45887173, 11368];
x = [Math.pow(2.0, -40.0), Math.pow(2.0, -14.0)];
var rnd40_64 = function() {
	//console.log('x=', x)
	//console.log("--------------------")

	//console.log("m=", m)
	//console.log("u=", u)

	var c0 = m[0]*u[0]
	//console.log("c0=",c0)
	var c1 = m[0]*u[1] + m[1]*u[0]
	//console.log("c1=",c1)
	
	//console.log(((c0 >> 26) << 26))

	u[0] = c0 - left_shift_26(right_shift_26_v2(c0))
	var n = c1 + right_shift_26_v2(c0)
	u[1] = n - left_shift_14(right_shift_14_v2(n))

	//console.log("u=", u)

	return u[0]*x[0] + u[1]*x[1];
}

/*for (var i=0; i < 10; i++) {
	console.log(rnd40_64());
}*/

var MQ = MathQuill.getInterface(2);

// Darken a color
      function darkenColor(colorStr) {
        // Defined in dygraph-utils.js
        var color = Dygraph.toRGB_(colorStr);
        color.r = Math.floor((color.r));
        color.g = Math.floor((color.g));
        color.b = Math.floor((color.b));
        return 'rgba(' + color.r + ',' + color.g + ',' + color.b + ', 0.3)';
      }

function barChartPlotter(e) {
    var ctx = e.drawingContext;
    var points = e.points;
    var y_bottom = e.dygraph.toDomYCoord(0);

    ctx.fillStyle = darkenColor(e.color);

    // Find the minimum separation between x-values.
    // This determines the bar width.
    var min_sep = Infinity;
    //console.log('p',points)
    var points2 = []

    for (var i=0; i < points.length; i++) {
    	
    	if (isNaN(points[i].y) == false) {
    		points2.push(points[i])
    	}
    }
    //console.log('p2',points2)
    for (var i = 1; i < points2.length; i++) {
      var sep = points2[i].canvasx - points2[i - 1].canvasx;
      if (sep < min_sep) min_sep = sep;
    }
    var bar_width = Math.floor(min_sep);

    // Do the actual plotting.
    for (var i = 0; i < points2.length; i++) {
      var p = points2[i];
      var center_x = p.canvasx;

      ctx.fillRect(center_x - bar_width / 2, p.canvasy,
          bar_width, y_bottom - p.canvasy);

      ctx.strokeRect(center_x - bar_width / 2, p.canvasy,
          bar_width, y_bottom - p.canvasy);
    }
  }

var calculator = {
	validate_latex_expr: function(latex_expr) {
		var valid = true
		var expr = nerdamer.convertFromLaTeX(latex_expr)
		try {
			nerdamer(expr)
		} catch (Error) {
			console.log(Error)
			valid = false
		}

		return valid;
	},
	validate_expr: function(expr) {
		var valid = true
		try {
			nerdamer(expr)
		} catch (Error) {
			console.log(Error)
			valid = false
		}

		return valid;
	},
	get_function: function(expr, args) {
		if (this.validate_expr(expr)) {
			return nerdamer(expr).buildFunction(args)
		}
	}
}

var main_block = {
	block_id: 'main_block',
	/*
	plotter: new Dygraph(
        document.getElementById('main_block'),
        [[0, 0, 0]],
        {
          labels: ['Date', 'B', 'A'],
          includeZero: true,
          series: {
          	"B": {
              plotter: barChartPlotter,
              stepPlot: true,
              strokeWidth: 2,
              color: 'orange',
              connectSeparatedPoints: true,
            },
            "A": {
              strokeWidth: 5,
              color: 'white',
              connectSeparatedPoints: true
            },
            
          }
       	}),
	*/
	plotter: echarts.init(document.getElementById('main_block')),
	graph_func: 'none',
	hist_func: 'none',
	min_y: 0,
	max_y: 1,
	min_x: 0,
	max_x: Math.sqrt(2),
	x: [],
	y1: [],
	y2: []
	
}

// отображение информации о формулах
var left_info_block = {
	block_id: "left_info_block",

}

var right_info_block = {
	block_id: "right_info_block",

}


// рендер формул в KaTeX'е
var left_formula_block = {
	block_id: "left_formula_block",

}

var right_formula_block = {
	block_id: "right_formula_block"
}

// блоки ввода формул
var left_formula_input_block = {

	block_id: "left_formula_input_block",
	open: function() {
		show(this.block_id)
		left_formula_input_block.editor.focus();
		set_rel_pos('#inner_left_formula_editor', get_size('#left_formula_editor').x/2 - get_size('#inner_left_formula_editor').x/2, get_size('#left_formula_editor').y/2 - get_size('#inner_left_formula_editor').y/2)
		
	},
	editor: MQ.MathField(document.getElementById('inner_left_formula_editor'), {
    	handlers: {
      		edit: function() {
      			set_rel_pos('#inner_left_formula_editor', get_size('#left_formula_editor').x/2 - get_size('#inner_left_formula_editor').x/2, get_size('#left_formula_editor').y/2 - get_size('#inner_left_formula_editor').y/2)
        		console.log(left_formula_input_block.editor.latex())

      		}
    	}
	}),
	start: function() {
		hide(this.block_id);
		if (calculator.validate_latex_expr(left_formula_input_block.editor.latex()) == true) {
			var expr = nerdamer.convertFromLaTeX(left_formula_input_block.editor.latex()).toString()
			main_block.graph_func = calculator.get_function(expr)
			var a = 0
			var b = Math.sqrt(2)
			var n = 1000
			var step = (b-a)/n
			var data_x = [];
			var data_y = []
			for (var x=a; x <= b; x+=step) {
				var y = main_block.graph_func(x)

				if (main_block.min_y > y) {
					main_block.min_y = y
				}
				if (main_block.max_y < y) {
					main_block.max_y = y
				}
				main_block.x.push(x);
				main_block.y1.push(y);
				data_x.push(parseFloat(x.toFixed(3)))
				data_y.push(parseFloat(y.toFixed(3)))

			}



			console.log(data_x)
			console.log(data_y)
			main_block.plotter.setOption({
				xAxis: {
					name: "graph",
					data: data_x
				},
                series: [{
                    name: 'graph',
                    data: data_y
                }]
            })
			//main_block.plotter.updateOptions({"file":data})
		}
		return false;
	}
}

var right_formula_input_block = {
	block_id: "right_formula_input_block",
	open: function() {
		show(this.block_id)
		set_rel_pos('#inner_right_formula_editor', get_size('#right_formula_editor').x/2 - get_size('#inner_right_formula_editor').x/2, get_size('#right_formula_editor').y/2 - get_size('#inner_right_formula_editor').y/2)


	},
	editor: MQ.MathField(document.getElementById('inner_right_formula_editor'), {
    	handlers: {
      		edit: function() {
      			set_rel_pos('#inner_right_formula_editor', get_size('#right_formula_editor').x/2 - get_size('#inner_right_formula_editor').x/2, get_size('#right_formula_editor').y/2 - get_size('#inner_right_formula_editor').y/2)


      		}
    	}
	}),
	start: function() {
		hide(this.block_id)
		if (calculator.validate_latex_expr(right_formula_input_block.editor.latex()) == true) {
			var expr = nerdamer.convertFromLaTeX(right_formula_input_block.editor.latex()).toString()
			console.log(expr)
			main_block.hist_func = calculator.get_function(expr)
			//console.log(main_block.hist_func)
			var cols_num = 40;
			var values_num = 1000000;

			var cols = [];
			var step = ( main_block.max_x - main_block.min_x ) / (cols_num-1);
			console.log(step)
			//console.log(cols, cols_num);
			for (var i=0; i < cols_num; i++) {
				console.log(i);
				cols.push(0)
			}
			//console.log(cols)
			var bad_nums = 0
			for (var i=0; i < values_num; i++) {
				var y = main_block.hist_func(Math.random())
				var need_col = Math.round((y)/(main_block.max_x-main_block.min_x)*cols_num)
				if (need_col < cols_num) {
					cols[need_col]++;
				} else {
					bad_nums++;
				}
			}
			//console.log(bad_nums)
			//console.log(cols)
			var max_col = 0
			var min_col = 100
			for (var i=0; i < cols_num; i++) {
				//console.log(cols[i])
				if (cols[i] > max_col) {
					max_col = cols[i]
				}

			}
			console.log('max_col', max_col)
			for (var i=0; i < cols_num; i++) {
				//console.log(i)
				cols[i] /= (max_col/main_block.max_y)
			}
			console.log(main_block.max_y)
			console.log(cols)
			var raw_data = []
			/*
			for (var i=0; i < cols_num; i++) {
				var col_x = i*step;
				for (var j=0; j < main_block.plotter.rawData_.length; j++) {
					if (main_block.plotter.rawData_[j][0] == col_x) {
						raw_data.push([main_block.plotter.rawData_[j][0], main_block.plotter.rawData_[j][1], cols[i]])
						
					} else if (main_block.plotter.rawData_[j][0] > col_x) {
						raw_data.push([col_x, NaN, cols[i]])
						raw_data.push(main_block.plotter.rawData_[j])
						break
					}
				}
			}*/
			var new_x1 = []
			var new_y1 = []
			var new_y2 = []
			var last_col = -1;
			/*
			for (var i=0; i < main_block.x.length; i++) {
				var col = main_block.x[i];
				//console.log(last_col*step)
				if (last_col*step < col) {
					
					new_x1.push(last_col*step)
					new_y2.push(cols[last_col])
					new_y1.push(main_block.graph_func(col))
 					//raw_data.push([col, cols[last_col], main_block.graph_func(col)])
					//raw_data.push(main_block.plotter.rawData_[i])
					last_col++;
				} else if (last_col*step == col) {
					//new_x1.push(col)
					new_y2.push(cols[last_col])
					//new_y1.push(main_block.y1[i])
					//raw_data.push([col, cols[last_col], main_block.plotter.rawData_[i][2]])
					//raw_data.push(main_block.plotter.rawData_[i])
					last_col++;
				} else {
					//new_x1.push(main_block.x[i])
					//new_y1.push(main_block.y1[i])
					new_y2.push(new_y2[new_y2.length-1])
					//raw_data.push(main_block.plotter.rawData_[i])
				}
			}
			*/
			//new_x1.push(last_col*step)
			new_x1 = []
			
			for (var i=0; i < cols_num; i++) {
				new_x1.push(parseFloat((step*i).toFixed(3)))
				cols[i] = parseFloat((cols[i]).toFixed(3))
			}
			
			//new_x1.push(last_col*step)
			//console.log(raw_data)
			console.log("x1", new_x1)
			console.log(new_y2)
			main_block.plotter.setOption({
				
				xAxis: [{
					name: "hist",
                    data: new_x1
                }],
                
                series: [{
                    name: 'hist',
                    //type: "bar",
                    //step: "middle",

                    data: cols,

                }/*, {
                	
                    name: 'graph',
                    data: new_y1,

                
                }*/
                ]
            })
			//main_block.plotter.updateOptions({"file": raw_data})
			
		}
		return false;
	}
}




// базовые/абстрактные функции, которые не имеет смысла в внедрять как методы в объектам
var hide = function(id) {
	$('#'+id).css('display', 'none');
}

var show = function(id) {
	$('#'+id).css('display', 'block');
}
// specify chart configuration item and data
var option = {
    title: {
        text: ''
    },
    backgroundColor: '#261100',
    darkMode: false,
    //backgroundColor: "#100C2A",
    tooltip: {
    	trigger: 'axis',
        axisPointer: {
            type: 'cross',
            crossStyle: {
                color: '#999'
            },
            animated: true,
            /*
            lineStyle: {
            		color: 'rgb(255, 140, 0)',
				    shadowColor: 'rgba(255, 140, 0, 0.5)',
				    shadowBlur: 10
				
            }
            */
        }
    },
    legend: {
        data:['comp']
    },
    xAxis: [{
    	//type: 'value',
    	type:"category",
    	name: "hist",
        data: [],

    }, {
    	name: "graph",
    	type:"category",
    	data: []
    }] ,
    yAxis: {
    	/*
        type: 'value',
        boundaryGap: [0, '100%'],
        splitLine: {
            show: false
        }
        */
    },
    series: [{
        name: 'hist',
        //type: 'bar',
        type: "bar",
        //step: 'middle',
        data: [],
        //connectNulls: true,
        xAxisIndex: 0,
        color: 'orange',
        itemStyle: {
    		shadowColor: 'rgba(255, 140, 0, 0.5)',
    		shadowBlur: 10
    	}

    }, {
    	name: "graph",
    	type: 'line',
    	data: [],
    	showSymbol: false,
    	xAxisIndex: 1,
    	color: 'white',
    	lineStyle: {
    		shadowColor: 'rgba(255, 255, 255, 0.5)',
    		shadowBlur: 10,
    		width: 5
    	}
    }]
};

// use configuration item and data specified to show chart
main_block.plotter.setOption(option);